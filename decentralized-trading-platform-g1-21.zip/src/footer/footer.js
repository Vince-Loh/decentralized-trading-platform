/*

Group 21:

Student Name: Vince Loh
Student ID: 102450160

Student Name: Kyle Barthelson 
Student ID: 104035705

Student Name: Nial Jones 
Student ID: 104152769

*/

import React from 'react';
import './footer.css';

function Footer() {
    return (
        <div className="footer">
            <p>© 2023 by COS30049 - Group 21. </p>
            <br />
            <p>All rights reserved.</p>
        </div>
    );
}

export default Footer;